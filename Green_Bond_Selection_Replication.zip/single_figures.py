from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
root=Path(__file__).resolve().parent
c=pd.read_csv(root/'single_cells.csv')
fig,axes=plt.subplots(1,2,figsize=(8.5,3))
b=c[c.policy=='baseline'].copy()
b['year']=b.m.str[:4]
groups=pd.cut(b.eligible,[-1,0,1,10000],labels=['No eligible issue','One issue','Two or more'])
counts=pd.crosstab(b.year,groups)
counts.plot.bar(stacked=True,color=['#aa6249','#dfbe7d','#28656c'],ax=axes[0],width=.76)
axes[0].set(xlabel='',ylabel='Month–maturity cells',title='A. Feasibility of the mandate')
axes[0].legend(fontsize=7,frameon=False)
z=b[b.eligible>1]
axes[1].scatter(z.gap,z.stable*100,s=13,color='#24616d',alpha=.56)
axes[1].set(xlabel='Score margin over runner-up',ylabel='Weight settings retaining winner (%)',title='B. Stability of the first choice')
for ax in axes:
 ax.spines[['right','top']].set_visible(False)
 ax.title.set_fontsize(10)
fig.tight_layout();fig.savefig(root/'single_figure.png',dpi=200);plt.close(fig)
