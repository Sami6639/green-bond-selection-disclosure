"""Paired single-issue checks on the licensed historical ranking output."""
from pathlib import Path
import numpy as np
import pandas as pd

out = Path(__file__).resolve().parent
rank = pd.read_csv(out/'local_single_ranks.csv')
issues = pd.read_csv(out/'local_security_audit.csv')
keys = ['m','band']
rank = rank.merge(issues[keys+['id','life']], on=keys+['id'],validate='one_to_one')
from argparse import ArgumentParser
import duckdb
parser=ArgumentParser()
parser.add_argument('data')
args=parser.parse_args()
daily=duckdb.sql(f"""select ISIN id,cast(observation_date as date) dt, median(BID) bid, median(ASK) askp from read_parquet('{Path(args.data)}/LSEG_Yesil_Tahvil_Gunluk*.parquet') where RCSCurrencyLeaf='Euro' and IsGreenBond='1' and length(trim(ISIN))=12 and cast(observation_date as date)>=cast(IssueDate as date) and BID>0 and ASK>=BID group by 1,2""").df()
daily['s']=20000*(daily.askp-daily.bid)/(daily.askp+daily.bid)
daily['m']=daily.dt.dt.to_period('M')
monthly=daily.groupby(['id','m']).agg(s=('s','median'),days=('dt','size'),last=('dt','max')).reset_index()
monthly=monthly[(monthly.days>=5)&((monthly.m.dt.to_timestamp('M')-monthly['last']).dt.days<=5)].copy()
monthly['m']=(monthly.m-3).astype(str)
rank=rank.merge(monthly[['id','m','s']].rename(columns={'s':'future'}),on=['id','m'],how='left',validate='many_to_one')
def interval(x):
    v=x.dropna().copy()
    v.index=pd.PeriodIndex(v.index,freq='M')
    v=v.reindex(pd.period_range(v.index.min(),v.index.max(),freq='M'))
    n=v.count()
    u=(v-v.mean()).fillna(0).to_numpy()
    var=u@u+sum(2*(1-j/4)*(u[:-j]@u[j:]) for j in (1,2,3))
    e=1.96*np.sqrt(max(0,var))/n
    return [n,v.mean(),v.mean()-e,v.mean()+e]
rows=[]
for key,g in rank.groupby(keys):
    win=g.loc[g['rank'].idxmin()]
    other=g[g.id!=win.id]
    for label,candidates in [('competitive_max_yield',other),('tightest_quote',other),('credit_maturity',other[(other.credit==win.credit)&((other.life-win.life).abs()<=.5)])]:
        if candidates.empty:continue
        # The unrestricted benchmarks can choose the same security as the model.
        if label!='credit_maturity': candidates=g
        else: candidates=g[(g.credit==win.credit)&(abs(g.life-win.life)<=.5)]
        field='spread' if label=='tightest_quote' else 'yield'
        comp=candidates.sort_values([field,'id'],ascending=[field=='spread',True]).iloc[0]
        ds=win.spread-comp.spread
        future=win.future-comp.future
        rows.append([*key,label,win['yield']-comp['yield'],win.credit-comp.credit,ds,future,future-ds,abs(win.life-comp.life),int(win.id==comp.id)])
cell=pd.DataFrame(rows,columns=keys+['benchmark','yield_pp','grade','spread0','spread3','change','maturity_gap','same_issue'])
cell.to_csv(out/'primary_check_cells.csv',index=False)
summary=[]
for label,g in cell.groupby('benchmark'):
    for col in cell.columns[3:]:
        summary.append([label,col,g[col].count(),*interval(g.groupby('m')[col].mean())])
pd.DataFrame(summary,columns=['benchmark','metric','cells','months','mean','lo','hi']).to_csv(out/'primary_check_stats.csv',index=False)
pre=issues[issues.m<'2024-01'].groupby('id').size().sort_values(ascending=False)
docs=pd.read_csv(out/'document_register.csv').ISIN
print('pre-2024 counts',pre.head(10).to_dict(), 'audited',pre.loc[docs].to_list())
# Fixed-size coverage benchmark. Draw only from issues identified before 2024.
# A draw fixes all seven securities throughout the evaluation window.
pool=pre.rename('n').rename_axis('id').reset_index().sort_values(['n','id'],ascending=[False,True]).head(30).id.tolist()
later=rank.loc[rank.m>='2024-01']
all_cells=pd.read_csv(out/'single_cells.csv').query("policy=='documented'")[keys]
presence=(pd.crosstab([later.m,later.band],later.id).reindex(index=pd.MultiIndex.from_frame(all_cells),columns=pool).fillna(0).to_numpy()>0)
rng=np.random.default_rng(20261120)
sims=[]
for _ in range(5000):
    n=presence[:,rng.choice(len(pool),7,replace=False)].sum(axis=1)
    sims.append([sum(n>0),sum(n>1)])
pd.DataFrame(sims,columns=['feasible','competitive']).to_csv(out/'seven_issue_comparison.csv',index=False)
print('seven-issue sets: 5%, median, 95%',np.quantile(sims,[.05,.5,.95],axis=0))
restricted=cell[cell.benchmark=='credit_maturity'].set_index(keys)
paired=cell[cell.benchmark=='competitive_max_yield'].set_index(keys).loc[restricted.index]
print('Same-cell unrestricted comparison',paired.groupby(level=0)[['yield_pp','spread3']].mean().mean().to_dict())
