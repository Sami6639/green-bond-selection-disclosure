"""Dated allocation and impact screens applied to the original financial universe."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent
reg=pd.concat([pd.read_csv(root/'evidence_events.csv'),pd.read_csv(root/'probability_audit.csv').dropna(subset=['tier'])],ignore_index=True)
allr=pd.read_csv(root/'local_single_ranks.csv')
cells=pd.read_csv(root/'single_cells.csv').query("policy=='baseline' and m >= '2024-01'")
assert not reg.duplicated(['isin','asof_month']).any()
assert set(reg['isin'])<=set(allr.id)
raw=np.array([[1,1,1],1/(1+np.array([.75,.5,.25])),1/((1+np.array([.75,.5,.25]))*(1+np.array([.5,.25,0])))])
weights=raw.mean(axis=1);weights/=weights.sum()
def choose(g):
    g=g.sort_values('id')
    x=g[['credit','spread','yield']].rank(pct=True).to_numpy()
    x[:,1]=1+1/len(x)-x[:,1]
    v=x*weights
    lo=np.linalg.norm(v-v.min(0),axis=1);hi=np.linalg.norm(v-v.max(0),axis=1)
    scores=np.divide(lo,lo+hi,out=np.full(len(g),.5),where=lo+hi>0)
    return g.iloc[scores.argmax()]
rows=[]
for c in cells.itertuples():
    g=allr[(allr.m==c.m)&(allr.band==c.band)].copy()
    for name,lag,exclude_bounds,minlevel in [('allocation',0,False,1),('impact',0,False,2),('impact_lag3',3,False,2),('impact_no_bounds',0,True,2),('tranche_impact',0,False,2),('release_impact',0,False,2),('recent_impact',0,False,2)]:
        e=reg[pd.PeriodIndex(reg.asof_month,freq='M')+lag < pd.Period(c.m)]
        if exclude_bounds:e=e[e.dating!='bound']
        if name=='release_impact':e=e[e.dating=='release']
        if name=='recent_impact':e=e[pd.PeriodIndex(e.asof_month,freq='M')>=pd.Period(c.m)-24]
        if name=='tranche_impact':e=e[e.scope=='issue']
        ids=set(e[e.tier>=minlevel]['isin'])
        sub=g[g.id.isin(ids)]
        rec=dict(m=c.m,band=c.band,screen=name,financial=len(g),eligible=len(sub))
        if len(g):
            win=g[g['rank']==1].iloc[0]
            high=g.sort_values(['yield','id'],ascending=[False,True]).iloc[0]
            rec.update(winner_covered=int(win.id in ids),yield_winner_covered=int(high.id in ids))
        if len(sub):
            alt=choose(sub)
            rec.update(changed=int(alt.id!=win.id),yield_difference=alt['yield']-win['yield'],grade_difference=alt.credit-win.credit,spread_difference=alt.spread-win.spread,eligible_incumbent_displaced=int(win.id in ids and alt.id!=win.id))
        rows.append(rec)
out=pd.DataFrame(rows)
out.to_csv(root/'environmental_cells.csv',index=False)
summary=[]
for name,g in out.groupby('screen',sort=False):
    ok=g[g.eligible>0]
    metrics=ok.groupby('m')[['yield_difference','grade_difference','spread_difference']].mean().mean()
    summary.append(dict(screen=name,cells=len(g),financial_cells=(g.financial>0).sum(),feasible=len(ok),competitive=(g.eligible>1).sum(),covered=g.winner_covered.sum(),yield_covered=g.yield_winner_covered.sum(),changed=ok.changed.sum(),rank_reversal=ok.eligible_incumbent_displaced.sum(),**metrics.to_dict()))
res=pd.DataFrame(summary);res.to_csv(root/'environmental_summary.csv',index=False)
print(res.round(3).to_string(index=False))
print('ISIN count',reg['isin'].nunique(), 'with metrics',reg[reg.tier==2]['isin'].nunique())
fig,ax=plt.subplots(figsize=(7,3.65))
names=['Allocation','Allocation + impact','Impact, extra 3-month lag','Impact, dated sources only','Tranche-specific impact','Dated public release only','Evidence cutoff within 24 months']
base=np.zeros(len(res))
for vals,label,color in [(res.cells-res.feasible,'No candidate','#cbd3d6'),(res.feasible-res.competitive,'One candidate','#d8a65c'),(res.competitive,'At least two','#29616b')]:
    ax.barh(names,vals,left=base,color=color,label=label)
    for i,n in enumerate(vals):
        if n>=6:ax.text(base[i]+n/2,i,str(n),va='center',ha='center',fontsize=8,color='white' if label=='At least two' else '#18272a')
    base+=vals
ax.invert_yaxis();ax.set_xlabel('Month–maturity cells, January 2024–July 2026');ax.spines[['top','right']].set_visible(False);ax.legend(ncol=3,loc='upper center',bbox_to_anchor=(.43,1.23),frameon=False,fontsize=8)
fig.tight_layout();fig.savefig(root/'evidence_figure.png',dpi=205);plt.close(fig)
