"""Compare documentation coverage and audit historical conventional matches."""
from pathlib import Path
import sys
import duckdb
import pandas as pd
here = Path(__file__).resolve().parent
root = Path(sys.argv[1])
p = pd.read_csv(here / 'local_single_picks.csv')
p = p.loc[p.rule.eq('fuzzy')].set_index(['m', 'band'])
common = p[p.policy.eq('documented')].join(p[p.policy.eq('baseline')], lsuffix='_doc', rsuffix='_broad', how='inner')
metrics = ['y','credit','initial','spread','netprice']
delta = common[[v+'_doc' for v in metrics]].to_numpy() - common[[v+'_broad' for v in metrics]].to_numpy()
pd.DataFrame(delta,index=common.index,columns=metrics).groupby(level=0).mean().to_csv(here/'documentation_contrasts.csv')
ref = next(root.glob('*Adaylari*'))
green = str(root/'LSEG_Yesil_Tahvil_Gunluk*.parquet')
conv = str(root/'LSEG_Konvansiyonel_Tahvil_Gunluk*.parquet')
universe = pd.read_csv(here/'local_security_audit.csv')[['m','id']].drop_duplicates()
matched = duckdb.sql(f"""
with green_end as (
 select g.ISIN gid, g.RIC ric, g.IssuerOAPermID issuer, g.MaturityDate mat, u.m,
 cast(g.observation_date as date) dt, median(g.YLDTOMAT) gy
 from read_parquet('{green}') g join universe u on g.ISIN=u.id and substr(cast(g.observation_date as varchar),1,7)=u.m
 where g.BID>0 and g.ASK>=g.BID and g.RCSCurrencyLeaf='Euro'
 group by 1,2,3,4,5,6 qualify dense_rank() over(partition by gid,m order by dt desc)=1
), candidates as (
 select g.*, c.ISIN cid, median(c.YLDTOMAT) cy, abs(date_diff('day',cast(g.mat as date),cast(c.MaturityDate as date))) gap
 from green_end g join '{ref}' r on g.ric=r.matched_green_RIC and r.IsGreenBond='0' and r.IsESGBond='0'
 join read_parquet('{conv}') c on r.ISIN=c.ISIN and cast(c.observation_date as date)=g.dt
 where c.IssuerOAPermID=g.issuer and c.RCSCurrencyLeaf='Euro' and c.BID>0 and c.ASK>=c.BID
 and cast(c.IssueDate as date)<=g.dt and cast(c.MaturityDate as date)>g.dt and c.YLDTOMAT is not null and g.gy is not null
 group by all)
 select * from candidates where gap<=730 qualify row_number() over(partition by gid,m order by gap,cid)=1
""").df()
print('matched',len(matched),matched.gid.nunique(),matched.cid.nunique(),matched.m.nunique())
if len(matched):
 matched['difference_bp']=(matched.gy-matched.cy)*100
 matched.groupby('m').difference_bp.agg(['mean','median','size']).to_csv(here/'conventional_check.csv')
print('document common',len(common),common.id_doc.nunique(),len(common.groupby(level=0)),(common.id_broad==common.id_doc).sum())
print(pd.read_csv(here/'documentation_contrasts.csv').mean(numeric_only=True))
