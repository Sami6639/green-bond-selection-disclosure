"""Conditional persistence using the licensed inputs and the baseline eligibility rules."""
from analysis import a, out
import pandas as pd
import numpy as np

variables=['s','credit','y','life','exitspread','price']
panel=a.loc[a.groupby(['m','band'],observed=True).id.transform('size')>=5].copy()
panel=panel.dropna(subset=variables)
ranks=panel.groupby(['m','band'],observed=True)[variables].rank(pct=True)
ranks-=ranks.groupby([panel.m,panel.band],observed=True).transform('mean')
coefs=[]
for month,g in ranks.groupby(panel.m):
    X=g[['s','credit','y','life']].to_numpy()
    if len(g)<20 or np.linalg.matrix_rank(X)<4:
        continue
    for outcome in ['exitspread','price']:
        estimates=np.linalg.lstsq(X,g[outcome].to_numpy(),rcond=None)[0]
        coefs.append([str(month),outcome,len(g),*estimates])
b=pd.DataFrame(coefs,columns=['month','outcome','n','s','credit','y','life'])
b.to_csv(out/'conditional_monthly.csv',index=False)
rows=[]
for outcome,g in b.groupby('outcome'):
    for name in ['s','credit','y','life']:
        v=g.set_index('month')[name]
        v.index=pd.PeriodIndex(v.index,freq='M')
        v=v.reindex(pd.period_range(v.index.min(),v.index.max(),freq='M'))
        u=(v-v.mean()).fillna(0).to_numpy()
        var=u@u+sum(2*(1-j/4)*(u[:-j]@u[j:]) for j in [1,2,3])
        err=1.96*np.sqrt(var)/v.count()
        rows.append([outcome,name,len(g),int(g.n.sum()),v.mean(),v.mean()-err,v.mean()+err])
res=pd.DataFrame(rows,columns=['outcome','criterion','months','bond_months','mean','lower','upper'])
res.to_csv(out/'conditional_summary.csv',index=False)
print(res.to_string(index=False))
