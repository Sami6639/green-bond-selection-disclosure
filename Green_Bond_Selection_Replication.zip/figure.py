from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
out=Path(__file__).parent
f=pd.read_csv(out/'base.csv')
z=f.pivot(index=['m','band'],columns='rule',values='exitspread');v=(z.model-z['yield']).groupby(level=0).mean();x=pd.to_datetime(v.index)
fig,axes=plt.subplots(2,1,figsize=(8.2,4.3),sharex=True)
for ax,title,limits in zip(axes,['A. All observations','B. Detail from −100 to +15 bp'],[None,(-100,15)]):
 ax.plot(x,v.where(v.between(-100,15)) if limits else v,color='#234c68',lw=1.15,marker='.',markersize=2.7)
 if limits:ax.set_ylim(limits)
 ax.axhline(0,color='0.45',lw=.65);ax.grid(axis='y',alpha=.15);ax.spines[['top','right']].set_visible(False);ax.set_ylabel('Basis points');ax.set_title(title,loc='left',fontsize=10)
axes[0].annotate('Jan. 2022',xy=(x[v.argmin()],v.min()),xytext=(pd.Timestamp('2023-02-01'),-600),arrowprops={'arrowstyle':'->'})
fig.tight_layout();fig.savefig(out/'figure1.png',dpi=220);plt.close(fig)

import numpy as np
def finish(fig,name):
    fig.tight_layout()
    fig.savefig(out/name,dpi=240,bbox_inches='tight')
    plt.close(fig)
# Unpaired inference is deliberately avoided. Dates differ by maturity band.
means=z.assign(delta=z.model-z['yield']).groupby('band').delta.agg(['mean','median','size']).reindex(['1–3','3–7','7–15','15+'])
fig,ax=plt.subplots(figsize=(7.3,2.7))
for i,(_,r) in enumerate(means.iterrows()):
    ax.plot([r['mean'],r['median']],[i,i],color='.72')
ax.scatter(means['mean'],range(4),label='Mean',color='#24465f')
ax.scatter(means['median'],range(4),label='Median',color='#b65a26',marker='D')
ax.set_yticks(range(4),[f'{b} years ({int(n)} months)' for b,n in zip(means.index,means['size'])]);ax.invert_yaxis()
ax.axvline(0,color='.4',lw=.7);ax.set_xlabel('Three-month spread difference (basis points)');ax.legend(frameon=False,loc='upper left');ax.spines[['top','right']].set_visible(False)
finish(fig,'figure2.png')
o=pd.read_csv(out/'overlap_cells.csv')
o['year']=o.month.str[:4]
ann=o.groupby('year')[['classic','equal','yield','k']].sum()
fig,ax=plt.subplots(figsize=(7.3,2.7))
for col,lab,color,marker in [('classic','Classical SWARA','#24465f','o'),('equal','Equal criteria','#b65a26','s'),('yield','Yield only','#588365','D')]:
    ax.plot(ann.index,100*ann[col]/ann.k,label=lab,color=color,marker=marker,lw=1.4)
ax.set_ylim(-3,108);ax.set_ylabel('Shared selections (%)');ax.set_xlabel('Formation year');ax.legend(frameon=False,ncol=3,loc='center',bbox_to_anchor=(.50,1.14));ax.spines[['top','right']].set_visible(False)
finish(fig,'figure3.png')
b=pd.read_csv(out/'conditional_summary.csv');fig,axes=plt.subplots(1,2,figsize=(7.3,2.6),sharey=True,sharex=True)
for ax,(outcome,title) in zip(axes,[('exitspread','Subsequent spread'),('price','Midpoint price change')]):
    g=b[b.outcome==outcome].set_index('criterion').loc[['s','credit','y','life']]
    ax.errorbar(g['mean'],range(4),xerr=np.array([g['mean']-g.lower,g.upper-g['mean']]),fmt='o',color='#24465f',capsize=3)
    ax.axvline(0,color='.4',lw=.8);ax.set_title(title,fontsize=10);ax.spines[['top','right']].set_visible(False);ax.set_xlabel('Mean rank slope')
axes[0].set_yticks(range(4),['Initial spread','Credit score','Yield','Remaining maturity']);axes[0].invert_yaxis()
finish(fig,'figure4.png')
