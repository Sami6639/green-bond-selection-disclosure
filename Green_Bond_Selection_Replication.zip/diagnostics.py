from analysis import a,run,score,w,cols,query,root
import numpy as np,pandas as pd
from pathlib import Path
out=Path(__file__).parent
names=query(f"""select ISIN id, min(IssuerName) issuer from read_parquet('{root}/LSEG_Yesil_Tahvil_Gunluk*.parquet') group by 1""")
z=a[a.m==pd.Period('2022-01','M')].merge(names,on='id').sort_values('fs',ascending=False)
print(z[['issuer','id','band','s','fs','y']].head(7).to_string(index=False))
# Rerun the full sort with an investment-grade eligibility threshold.
ig=run(a[a.credit>=13],False)
features=[]
for label,f in [('Investment grade',ig),('All',pd.read_csv(out/'base.csv'))]:
 for key in ['price','exitspread','change']:
  m=f.pivot(index=['m','band'],columns='rule',values=key)
  delta=(m.model-m['yield']).groupby(level=0).mean()
  features.append([label,key,len(delta),delta.mean(),delta.median(),delta[delta.index!='2022-01'].mean()])
pd.DataFrame(features,columns=['universe','metric','months','mean','median','without_jan22']).to_csv(out/'sensitivity.csv',index=False)
zz=a.merge(names,on='id')
f=run(zz[zz.issuer!='RZD Capital'],False)
for key in ['exitspread','change','price']:
 wide=f.pivot(index=['m','band'],columns='rule',values=key)
 v=(wide.model-wide['yield']).groupby(level=0).mean().dropna();print('exRZD',key,len(v),v.mean(),v.median())
pd.DataFrame(f).to_csv(out/'issuer_exclusion.csv',index=False)
