"""Validate historical selection and evidence coverage with a fixed probability draw."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import hypergeom
from environmental_selection import choose
root=Path(__file__).resolve().parent
ranks=pd.read_csv(root/'local_single_ranks.csv').query("m>='2024-01'")
population=sorted(ranks.id.unique())
review=pd.read_csv(root/'probability_audit.csv')
sample=np.random.default_rng(20261120).choice(population,size=24,replace=False)
assert review['isin'].tolist()==sample.tolist()
original=pd.read_csv(root/'evidence_events.csv')
combined=pd.concat([original,review.dropna(subset=['tier'])],ignore_index=True)
combined.to_csv(root/'combined_evidence_events.csv',index=False)
screen=combined[combined['isin'].isin(sample)]
N=len(population)
def admitted(events,month,level):
    return set(events.loc[(events.tier>=level)&(events.asof_month<month),'isin'])
def exact_count_interval(k):
    counts=np.arange(N+1)
    keep=(hypergeom.cdf(k,N,counts,24)>=.025)&(hypergeom.sf(k-1,N,counts,24)>=.025)
    return counts[keep][[0,-1]]
rows=[]
for level in [1,2]:
    for mode in ['as_of_final_formation','at_least_one_eligible_formation']:
        observed=admitted(screen,'2026-07',level) if mode=='as_of_final_formation' else set()
        if mode=='at_least_one_eligible_formation':
            for month,g in ranks.groupby('m'):
                observed.update(set(g.id)&admitted(screen,month,level))
        k=len(observed);lo,hi=exact_count_interval(k)
        rows.append([mode,level,k,24,N,100*k/24,100*lo/N,100*hi/N])
est=pd.DataFrame(rows,columns=['timing','tier','matched','sample','population','percent','lower','upper'])
est.to_csv(root/'probability_coverage.csv',index=False)
out=[]
for (month,band),g in ranks.groupby(['m','band']):
    finance=g.loc[g['rank']==1].iloc[0]
    for pool,register in [('combined',combined),('random_only',screen),('confirmed_release',combined[combined.dating=='release'])]:
        for level in [1,2]:
            ids=admitted(register,month,level);ok=g[g.id.isin(ids)]
            row=dict(m=month,band=band,pool=pool,tier=level,eligible=len(ok),financial_winner_covered=int(finance.id in ids))
            if len(ok):
                chosen=choose(ok)
                row.update(changed=int(chosen.id!=finance.id),yield_difference=chosen['yield']-finance['yield'],grade_difference=chosen.credit-finance.credit,spread_difference=chosen.spread-finance.spread)
            out.append(row)
cells=pd.DataFrame(out);cells.to_csv(root/'validation_cells.csv',index=False)
rows=[]
for (pool,level),g in cells.groupby(['pool','tier']):
    paired=g[g.eligible>0]
    metrics=paired.groupby('m')[['yield_difference','grade_difference','spread_difference']].mean().mean()
    rows.append(dict(pool=pool,tier=level,feasible=len(paired),competitive=sum(g.eligible>1),covered=sum(g.financial_winner_covered),changed=paired.changed.sum(),**metrics.to_dict()))
summary=pd.DataFrame(rows);summary.to_csv(root/'validation_summary.csv',index=False)
print(est.round(1).to_string(index=False));print(summary.round(3).to_string(index=False))
print('combined ISINs',combined['isin'].nunique(),combined.loc[combined.tier==2,'isin'].nunique())

# Month-clustered uncertainty for the main environmental comparison.
main = cells.loc[(cells.pool == 'combined') & (cells.tier == 2) & (cells.eligible > 0)]
monthly = -100 * main.groupby('m').yield_difference.mean()
monthly.index = pd.PeriodIndex(monthly.index, freq='M')
monthly = monthly.reindex(pd.period_range(monthly.index.min(), monthly.index.max(), freq='M'))
deviation = (monthly - monthly.mean()).fillna(0).to_numpy()
variance = deviation @ deviation
for lag in range(1,4):
    variance += 2 * (1 - lag / 4) * (deviation[:-lag] @ deviation[lag:])
half_width = 1.96 * np.sqrt(max(0,variance)) / monthly.count()
pd.DataFrame([dict(paired_cells=len(main),months=monthly.count(),positive_months=int((monthly>0).sum()),
                   yield_concession_bp=monthly.mean(),median_bp=monthly.median(),
                   lower_bp=monthly.mean()-half_width,upper_bp=monthly.mean()+half_width)]).to_csv(
                       root/'environmental_yield_precision.csv',index=False)
