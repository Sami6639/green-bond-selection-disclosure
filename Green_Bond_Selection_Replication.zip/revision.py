"""Run the existing diagnostics, then reproduce the revised manuscript exhibits."""
from diagnostics import a,score,cols,w,root,query,out
from analysis import candidates,d
import pandas as pd
import numpy as np
from scipy.optimize import linear_sum_assignment

def stats(values):
    values=values.copy()
    values.index=pd.PeriodIndex(values.index,freq='M')
    values=values.reindex(pd.period_range(values.index.min(),values.index.max(),freq='M'))
    n=values.count()
    u=(values-values.mean()).fillna(0).to_numpy()
    variance=u@u+sum(2*(1-j/4)*(u[:-j]@u[j:]) for j in (1,2,3))
    half=1.96*np.sqrt(variance)/n
    return [values.mean(),values.mean()-half,values.mean()+half]

crisp=np.array([1,1/1.5,1/(1.5*1.25)])
crisp/=crisp.sum()
pairs=[]
audits=[]
cells=[]
for (month,band),z in a.groupby(['m','band'],observed=True):
    if len(z)<5: continue
    z=z.sort_values('id').copy()
    k=int(np.ceil(len(z)/5))
    z['score_fuzzy']=score(z[cols],w)
    z['score_classic']=score(z[cols],crisp)
    ranked=z.nlargest(k,'score_fuzzy')
    classic=z.nlargest(k,'score_classic')
    income=z.nlargest(k,'y')
    for col,group in [('fuzzy',ranked),('classic',classic),('yield',income)]:
        z['selected_'+col]=z.id.isin(group.id)
    audits.append(z[['m','band','id','credit','s','y','life','score_fuzzy','score_classic','selected_fuzzy','selected_classic','selected_yield']])
    cells.append([str(month),str(band),len(z),k,len(set(ranked.id)&set(classic.id)),ranked.fs.mean()-classic.fs.mean(),ranked.price.mean()-classic.price.mean(),ranked.fs.mean()-income.fs.mean(),ranked.price.mean()-income.price.mean()])
    gap=np.abs(ranked.life.to_numpy()[:,None]-income.life.to_numpy())
    # Maximize eligible matches first, then minimize total maturity distance.
    penalty=(k+1)*2
    cost=np.c_[np.where(gap<=.5,gap,2*penalty),np.full((k,k),penalty)]
    ii,jj=linear_sum_assignment(cost)
    for i,j in zip(ii,jj):
        if j>=k: continue
        left,right=ranked.iloc[i],income.iloc[j]
        pairs.append([str(month),str(band),left.id==right.id,abs(left.life-right.life),left.life-right.life,left.fs-right.fs,left.price-right.price,left.s-right.s])
audit=pd.concat(audits)
audit.to_csv(out/'local_security_audit.csv',index=False)
c=pd.DataFrame(cells,columns=['month','band','n','k','overlap','classic_spread','classic_price','yield_spread','yield_price'])
c.to_csv(out/'selection_checks.csv',index=False)
p=pd.DataFrame(pairs,columns=['month','band','self','abs_years','years','spread','price','initial_spread'])
g=p.groupby(['month','band'])
g.mean().assign(n=g.size()).reset_index().to_csv(out/'maturity_matches.csv',index=False)
print('MATCH',len(p),sum(p.self),p.month.nunique(),len(g),p.abs_years.max(),p.abs_years.mean())
matched_stats=[[col,*stats(g[col].mean().groupby(level=0).mean())] for col in ['spread','price','years','initial_spread']]
pd.DataFrame(matched_stats,columns=['measure','mean','lower','upper']).to_csv(out/'maturity_match_stats.csv',index=False)
flow=[]
def count(stage,z):
    flow.append([stage,z.id.nunique(),len(z.drop_duplicates(['id','m']))])
raw=query(f"""select distinct ISIN id,date_trunc('month',cast(observation_date as date)) m from read_parquet('{root}/LSEG_Yesil_Tahvil_Gunluk*.parquet') where RCSCurrencyLeaf='Euro' and IsGreenBond='1' and length(trim(ISIN))=12""")
count('Euro issues in archive',raw)
count('Valid post-issue quotes, formation window',d[d.m<=pd.Period('2026-07')])
z=candidates
count('Monthly coverage and quote recency',z)
for col,name in [('band','Remaining maturity at least one year'),('credit','Definitive issue rating available'),('y','Yield observed on formation quote')]:
    z=z.dropna(subset=col);count(name,z)
count('At least five issues in month and band',audit)
pd.DataFrame(flow,columns=['stage','issues','bond_months']).to_csv(out/'sample_flow.csv',index=False)
print(flow)

overlaps=[]
for (month,band),g in audit.groupby(['m','band'],observed=True):
    g=g.sort_values('id')
    k=int(g.selected_fuzzy.sum())
    equal=g.iloc[np.argsort(-score(g[cols],np.ones(3)),kind='stable')[:k]]
    ids=set(g.loc[g.selected_fuzzy,'id'])
    overlaps.append([str(month),str(band),k,len(ids.intersection(equal.id)),
                     int((g.selected_classic & g.selected_fuzzy).sum()),
                     int((g.selected_yield & g.selected_fuzzy).sum())])
pd.DataFrame(overlaps,columns=['month','band','k','equal','classic','yield']).to_csv(out/'overlap_cells.csv',index=False)
