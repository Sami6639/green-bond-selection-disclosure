import os,sys,itertools
from pathlib import Path
import numpy as np,pandas as pd,duckdb
root=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/lsdata')
out=Path(__file__).parent
def query(s):return duckdb.sql(s).df()
d=query(f"""select ISIN id,cast(observation_date as date) dt,cast(MaturityDate as date) maturity,BID bidp,ASK askp,YLDTOMAT y,OAS_BID o from read_parquet('{root}/LSEG_Yesil_Tahvil_Gunluk*.parquet',union_by_name=true) where IsGreenBond='1' and RCSCurrencyLeaf='Euro' and length(trim(ISIN))=12 and cast(observation_date as date)>=cast(IssueDate as date) and BID>0 and ASK>=BID and observation_date<'2026-11-01'""")
d=d.groupby(['id','dt'],as_index=False).agg(dict(maturity='first',bidp='median',askp='median',y='median',o='median')).sort_values(['id','dt'])
d['mid']=(d.bidp+d.askp)/2
d['s']=10000*(d.askp-d.bidp)/d.mid;d['m']=d.dt.dt.to_period('M')
g=d.groupby(['id','m']); end=g.tail(1).copy().set_index(['id','m'])
end['s']=g.s.median();end['days']=g.s.count()
end=end.reset_index()
end=end[(end.days>=5)&((end.m.dt.to_timestamp('M')-end.dt).dt.days<=5)].copy()
r=query(f"""select ISIN id,cast("TR.GR.RATING.DATE" as date) rd,"TR.GR.RATING" rating,"TR.GR.RATING.RATINGSOURCEDESCRIPTION" agency from read_parquet('{root}/LSEG_Yesil_Tahvil_Moodys*.parquet')""").dropna()
f='AAA AA+ AA AA- A+ A A- BBB+ BBB BBB- BB+ BB BB- B+ B B- CCC+ CCC CCC- CC C D'.split()
m='Aaa Aa1 Aa2 Aa3 A1 A2 A3 Baa1 Baa2 Baa3 Ba1 Ba2 Ba3 B1 B2 B3 Caa1 Caa2 Caa3 Ca C'.split()
mp={v:22-i for a in [f,m] for i,v in enumerate(a)}
r['val']=r.rating.map(mp)
# Withdrawals, NR and provisional-only events supersede earlier definitive records.
def collapse(a):return a.min() if a.notna().all() else np.nan
for i,(_,grp) in enumerate(r.groupby('agency')):
 b=grp.groupby(['id','rd'],as_index=False).val.agg(collapse).rename(columns={'val':f'r{i}'})
 end=pd.merge_asof(end.sort_values('dt'),b.sort_values('rd'),left_on='dt',right_on='rd',by='id').drop(columns='rd')
end['credit']=end[['r0','r1']].min(axis=1);end['life']=(end.maturity-end.dt).dt.days/365.25
future=end[['id','m','mid','s','bidp']].copy();future['m']-=3;future=future.rename(columns={k:'f'+k for k in ['mid','s','bidp']})
a=end.merge(future,how='left',on=['m','id'])
a['price']=100*(a.fmid/a.mid-1);a['exitspread']=a.fs;a['change']=a.fs-a.s;a['cross']=100*(a.fbidp/a.askp-1)
a['band']=pd.cut(a.life,[1,3,7,15,np.inf],right=False,labels=['1–3','3–7','7–15','15+'])
candidates=a[a.m<=pd.Period('2026-07','M')].copy()
a=a.dropna(subset=['credit','y','band'])
a=a[a.m<=pd.Period('2026-07','M')].copy()
raw=np.array([[1,1,1],1/(1+np.array([.75,.5,.25])),1/((1+np.array([.75,.5,.25]))*(1+np.array([.5,.25,0])))])
w=raw.mean(axis=1);w/=w.sum()
cols=['credit','s','y']
def score(z,wt):
 x=z.rank(pct=True,ascending=True).to_numpy();x[:,1]=1+1/len(z)-x[:,1]
 v=x*wt; worst=np.linalg.norm(v-v.min(axis=0),axis=1);best=np.linalg.norm(v-v.max(axis=0),axis=1)
 return np.divide(worst,worst+best,out=np.full(len(z),.5),where=(worst+best)>0)
def run(a,oas=False):
 rows=[]; counts=[];sel=[]
 for (t,band),z in a.groupby(['m','band'],observed=True):
  z=z.sort_values('id').copy()
  if oas:z=z.dropna(subset='o');z['y']=z.o
  if len(z)<5:continue
  k=int(np.ceil(len(z)/5))
  def top(x):return z.iloc[np.argsort(-np.asarray(x),kind='stable')[:k]]
  rules={'model':top(score(z[cols],w)),'yield':top(z.y),'equal':top(score(z[cols],np.ones(3))),'all':z,'liquid':top(-z.s)}
  oriented=z[cols].copy()
  oriented['s']=-oriented['s']
  span=oriented.max()-oriented.min()
  active=span[span>0].index
  scaled=(oriented[active]-oriented[active].min())/span[active]
  info=scaled.std()*(1-scaled.corr()).sum()
  objective=info.reindex(cols,fill_value=0).to_numpy()
  if objective.sum()<1e-10:objective=np.array([float(c in active) for c in cols]) if len(active) else np.ones(3)
  objective/=objective.sum()
  rules['critic']=top(score(z[cols],objective))
  if not oas:
   for p in itertools.permutations(range(3)):
    rules['p'+''.join(map(str,p))]=top(score(z[cols],w[list(p)]))
  for name,b in rules.items():
   rec=dict(m=str(t),band=str(band),rule=name,n=len(b),follow=b.price.count(),wc=objective[0],wl=objective[1],wy=objective[2])
   for c in ['price','cross','exitspread','change','credit','s','y','life']:rec[c]=b[c].mean()
   rows.append(rec)
  sel.extend(z.id.tolist());counts.append((str(t),str(band),len(z)))
 fr=pd.DataFrame(rows); print('oas',oas,'weights',w,'sample',len(set(sel)),len(sel),len(counts),fr.m.nunique(),fr.m.min(),fr.m.max())
 return fr
for cond,name in [(False,'base'),(True,'oas'),(True,'oas_full')]:
 pool=candidates.dropna(subset=["credit","band","o"]) if name=="oas_full" else a
 fr=run(pool,cond);fr.to_csv(out/(name+'.csv'),index=False)
 print(fr.groupby('rule')[['n','follow']].sum().head(15))
 def hac(a):
  v=a.dropna().values;n=len(v);u=v-v.mean();lag=3;var=u@u+sum(2*(1-j/(lag+1))*(u[:-j]@u[j:]) for j in range(1,lag+1));se=np.sqrt(var)/n
  return [v.mean(),v.mean()-1.96*se,v.mean()+1.96*se,n]
 summary=[]
 for c in ['price','cross','exitspread','change','credit','s','y','life']:
  wide=fr.pivot(index=['m','band'],columns='rule',values=c)
  for rule in wide:
   mm=wide[rule].groupby(level=0).mean()
   summary.append([c,rule,'level',*hac(mm)])
   for comp in ['yield','all','equal','liquid','critic']:
    diff=(wide[rule]-wide[comp]).groupby(level=0).mean()
    summary.append([c,rule,comp,*hac(diff)])
 pd.DataFrame(summary,columns=['metric','rule','ref','mean','lo','hi','months']).to_csv(out/(name+'_stats.csv'),index=False)
