"""Single-issue selection within a documented green opportunity set.
Run after extracting the LSEG files listed in README.txt.
"""
from analysis import a, w, score, cols, root, out, query
import pandas as pd
import numpy as np
from itertools import product

policies={'baseline':(13,50),'tight_spread':(13,25),'wide_spread':(13,100),'high_credit':(16,50)}
fixed={'XS1702729275':1.25,'XS1704789590':1.50,'XS1909186451':2.50,'XS2009861480':1.125,'XS2055744689':.15,'XS2056491587':2.124,'XS2079716937':.50}
# For the seven-issue documentary exercise the common start is January 2024.
# Settlement proxies use quote dates. Contractual coupons are annual in the exercise.
raw=query(f"""select ISIN id,cast(observation_date as date) dt,median(BID) bid,median(ASK) ask,median(YLDTOMAT) y from read_parquet('{root}/LSEG_Yesil_Tahvil_Gunluk*.parquet') where RCSCurrencyLeaf='Euro' and IsGreenBond='1' and bid>0 and ask>=bid group by 1,2""")
quotes={i:g.sort_values('dt').set_index('dt') for i,g in raw.groupby('id')}
def getquote(g,date):
    p=g.index.searchsorted(date)
    if p==len(g) or (g.index[p]-date).days>5:return None
    return g.iloc[p]
def accrual(dt,mat,cp):
    anniversary=pd.Timestamp(dt.year,mat.month,mat.day)
    prev=anniversary if anniversary<=dt else anniversary-pd.DateOffset(years=1)
    nxt=prev+pd.DateOffset(years=1)
    return cp*(dt-prev).days/(nxt-prev).days
def outcomes(row):
    g=quotes[row.id]
    entry=getquote(g,row.m.to_timestamp('M')+pd.Timedelta(days=1))
    if entry is None:return {}
    exitq=getquote(g,entry.name+pd.DateOffset(months=3))
    if exitq is None:return {}
    res={'entry':str(entry.name.date()),'exit':str(exitq.name.date()),'netprice':100*(exitq.bid/entry.ask-1)}
    if row.id in fixed:
        mat=row.maturity;cp=fixed[row.id]
        # No coupon entitlement boundary is ambiguous when both dates are >5d from coupon.
        dates=[pd.Timestamp(yr,mat.month,mat.day) for yr in range(entry.name.year-1,exitq.name.year+2)]
        if min(abs((dt-cd).days) for dt in [entry.name,exitq.name] for cd in dates)<=5:return res
        cash=cp*sum(entry.name<cd<=exitq.name for cd in dates)
        accrued0=accrual(entry.name,mat,cp);accrued1=accrual(exitq.name,mat,cp)
        res.update(coupon_cash=cash,cashreturn=100*((exitq.bid+accrued1+cash)/(entry.ask+accrued0)-1),
                   dirty_scenario=100*((exitq.bid+cash)/entry.ask-1))
    return res

def tops(g,weight):
    # Precomputed criterion ranks speed up the weight grid.
    x=g[cols].rank(pct=True).to_numpy();x[:,1]=(1+1/len(g))-x[:,1]
    return x
def grades(x,weight):
    v=x*weight
    lo=np.linalg.norm(v-v.min(0),axis=1);hi=np.linalg.norm(v-v.max(0),axis=1)
    return np.divide(lo,lo+hi,out=np.full(len(x),.5),where=lo+hi>0)

def stats(g):
    v=g.dropna();idx=pd.PeriodIndex(v.index,freq='M')
    v=pd.Series(v.to_numpy(),index=idx)
    if len(v)==0:return [0,np.nan,np.nan,np.nan]
    v=v.reindex(pd.period_range(idx.min(),idx.max(),freq='M'))
    u=(v-v.mean()).fillna(0).to_numpy()
    var=u@u+sum(2*(1-j/4)*(u[:-j]@u[j:]) for j in (1,2,3))
    e=1.96*np.sqrt(max(0,var))/v.count()
    return [v.count(),v.mean(),v.mean()-e,v.mean()+e]

cells=[];picks=[];rankings=[]
scenarios=np.array([w*np.array(p) for p in product([.8,1,1.2],repeat=3)])
scenarios/=scenarios.sum(axis=1)[:,None]
for (t,b),z in a.groupby(['m','band'],observed=True):
    if len(z)<5:continue
    z=z.sort_values('id')
    for key,(floor,cap) in dict(policies,unrestricted=(0,np.inf),documented=(13,50)).items():
        if key=='documented' and t<pd.Period('2024-01'):continue
        g=z[(z.credit>=floor)&(z.s<=cap)]
        if key=='documented':g=g[g.id.isin(fixed)]
        rec=dict(m=str(t),band=str(b),policy=key,parent=len(z),eligible=len(g))
        if g.empty:
            cells.append(rec);continue
        x=tops(g,w);scores=grades(x,w);order=np.argsort(-scores,kind='stable');win=order[0]
        stable=np.mean([np.argmax(grades(x,ws))==win for ws in scenarios])
        rec.update(gap=(scores[win]-scores[order[1]]) if len(g)>1 else np.nan,stable=stable,identical=win==np.argmax(g.y.to_numpy()))
        cells.append(rec)
        for rule,i in [('fuzzy',win),('max_yield',np.argmax(g.y.to_numpy())),('classic',np.argmax(grades(x,np.array([1,2/3,8/15])))),('credit_liquid',g.index.get_loc(g.sort_values(['credit','s','y','id'],ascending=[False,True,False,True]).index[0])),('equal',np.argmax(grades(x,np.ones(3))))]:
            r=g.iloc[i]
            picks.append(dict(m=str(t),band=str(b),policy=key,rule=rule,id=r.id,y=r.y,credit=r.credit,initial=r.s,spread=r.fs,price=r.price,life=r.life,**outcomes(r)))
        if key=='baseline':
            for rank,i in enumerate(order):
                r=g.iloc[i];rankings.append([str(t),str(b),r.id,rank+1,scores[i],r.credit,r.s,r.y])
c=pd.DataFrame(cells);p=pd.DataFrame(picks);pd.DataFrame(rankings,columns=['m','band','id','rank','score','credit','spread','yield']).to_csv(out/'local_single_ranks.csv',index=False)
p.to_csv(out/'local_single_picks.csv',index=False)
c.to_csv(out/'single_cells.csv',index=False)
metrics=['y','credit','initial','spread','price','netprice','life','cashreturn','dirty_scenario']
summ=[]
for policy,g in p.groupby('policy'):
 for comparator in ['max_yield','classic','equal','credit_liquid']:
    left=g[g.rule=='fuzzy'].set_index(['m','band'])
    right=g[g.rule==comparator].set_index(['m','band'])
    contrast=left[metrics]-right[metrics]
    for period,lower,upper in [('all','0000','9999'),('early','0000','2023-09'),('late','2024-01','9999')]:
        part=contrast[(contrast.index.get_level_values('m')>=lower)&(contrast.index.get_level_values('m')<=upper)]
        for col in metrics:
            if part[col].count()==0:continue
            v=part[col].groupby(level=0).mean()
            summ.append([policy,comparator,period,col,part[col].count(),*stats(v)])
su=pd.DataFrame(summ,columns=['policy','comparator','period','metric','cells','months','mean','lower','upper']);su.to_csv(out/'single_contrasts.csv',index=False)
print(c.groupby('policy').eligible.agg(['size',lambda v:sum(v==0),lambda v:sum(v==1),lambda v:sum(v>1)]))
print(su.query("policy=='baseline' and comparator=='max_yield' and metric in ['y','credit','spread','netprice','price']").round(3).to_string(index=False))
print(su.query("policy=='documented' and comparator=='max_yield' and period=='all'").round(3).to_string(index=False))
print(c.query("policy=='baseline' and eligible>1")[['gap','stable','identical']].describe(include='all'))
